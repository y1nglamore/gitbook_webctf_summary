const FLAG = "ACTF{*****************************}"
const FAKE_FLAG = "only_admin_users_can_see_the_true_flag"
exports.FLAG = FLAG
exports.FAKE_FLAG = FAKE_FLAG